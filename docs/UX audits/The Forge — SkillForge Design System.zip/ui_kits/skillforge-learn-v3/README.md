# SkillForge — "learn" UI kit

A high-fidelity, interactive recreation of **The Living Forge** learner surface: the A2UI
agentic experience where the coach (**Jarvis**) *builds* UI live around the learner's next
move. This kit is a cosmetic prototype — the agentic loop is simulated with timers, not a
real SSE stream — but the visuals, motion, and interaction model are production-faithful to
the spec.

## Run it
Open `index.html`. The intro surface offers two moves:
- **Run a quick diagnostic** → Jarvis "thinks" (agent shimmer) → a 5-question diagnostic
  **welds** into existence. Answering mutates the *same* surface in place: the ring fills,
  the next question welds in where the last was, a `CoachNote` reacts. → results (SkillMeters
  tick up, praise).
- **How am I doing?** → Jarvis forges a **SkillMap** constellation. Tap a node → it forges
  the next lesson (or the prompt-craft `PromptDiff`) right there.
- **PromptDiff** → edit the prompt, hit **Forge**, the diff re-runs in place.

## The five signature moments (all demonstrable here)
1. **The Weld** — surfaces don't fade in; the block's hairline lights ember-hot and cools to
   neutral, children rise top-down. (See `forge.css` → `weld-cool` / `.weld-in`.)
2. **Living surfaces** — the diagnostic is one surface that mutates per answer; no reload.
   (`Diagnostic` in `app.jsx`.)
3. **Jarvis as ambient presence** — voice as in-surface `CoachNote`s + a breathing presence
   dot in the app bar; cool = thinking, ember = forging.
4. **The generative Skill Map** — `SkillMap` constellation; node size = mastery, ember ring =
   ready to level up, dashed ember edges = prerequisite paths.
5. **Prompt-craft side by side** — `PromptDiff` with add/del highlighting + a live verdict.

## Files
| File | Contents |
|---|---|
| `index.html` | Loads React + Babel + Lucide + the three JSX files |
| `forge.css` | The Forge visual system: weld, shimmer, grain, bloom, all component styles |
| `primitives.jsx` | `Icon` (Lucide), `Button`, `Presence`, `ProgressRing`, `SkillMeter`, `CoachNote`, `Reveal`, `CodeBlock` |
| `surface.jsx` | `Block`/`Weld`/`Welded` (the weld shell), `ThinkingBlock`, `QuizCard`, `Stepper`, `PromptDiff`, `SkillMap` |
| `app.jsx` | The orchestrated scenario — simulates Jarvis's think→forge→mutate loop |

## Component coverage vs. the A2UI `learn` catalog (§4.2)
Implemented: `Markdown` (prose), `ProgressRing`, `SkillMeter`, `Step`/`Stepper`, `QuizCard`,
`Reveal`, `CodeBlock`, `PromptDiff`, `CoachNote`, `SkillMap`. Inherited basics shown:
`Text`, `Button`, `TextField` (diff editor), `ChoicePicker` (quiz choices), `Divider`, `Icon`.

## Robustness notes (important)
- **Content is never hidden by animation.** Every element's base state is `opacity:1`; the
  weld reveal is a *transform-only* rise plus the block's ember border cool. So if the
  animation/transition timeline is paused (backgrounded tab, print, reduced-motion, a headless
  capture), the surface still shows readable content — it's just un-risen. No information is
  motion-only.
- **Reduced motion** collapses the weld and shimmer to static states (see `@media` in `forge.css`).
- **Icons** are real Lucide geometry via the UMD build (substitute for Linear's proprietary set).
- **Fonts** load from Fontshare (General Sans, Switzer) + Google (JetBrains Mono).

## What this kit deliberately does NOT do
No real backend, SSE transport, JSON-Pointer data model, or catalog validation — those are the
production runtime (spec §7). The diagnostic's "data model" is local React state standing in for
`updateDataModel`. Swap the timers for a real A2UI message stream to make it live.
