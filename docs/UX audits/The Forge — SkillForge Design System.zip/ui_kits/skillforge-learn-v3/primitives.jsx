/* primitives.jsx — leaf components for the SkillForge learn kit (REVISED / v2).
   Conformance fixes vs v1:
   · Button has NO icon/label prop — single child (a Row[Icon,Text]); emphasis enum only (V4)
   · Layout primitives Row / Column / Text / Markdown added (V5) — agent emits no CSS
   · ProgressRing: no agent-set px size (semantic scale enum); tone never decorative-ember (V3/V10)
   · SkillMeter: tone neutral|success only; delta flagged as a proposed extension (V11)
   · Reveal: bound `open` + onToggle action, not a one-time defaultOpen (V7)
   · CodeBlock copy = the registered copyToClipboard function (V8 family)
   Exported to window for cross-file (babel) sharing. */
const { useState, useEffect, useRef } = React;

/* ---- Icon: real Lucide geometry via the UMD build ---------------------- */
function Icon({ name, size = 18, color = "currentColor", className = "" }) {
  const ref = useRef(null);
  useEffect(() => {
    const host = ref.current;
    if (!host || !window.lucide) return;
    host.innerHTML = "";
    const i = document.createElement("i");
    i.setAttribute("data-lucide", name);
    host.appendChild(i);
    window.lucide.createIcons({ attrs: { "stroke-width": 1.75 } });
  }, [name]);
  return <span ref={ref} className={"icon " + className}
    style={{ width: size, height: size, color }} />;
}

/* ---- Row / Column — the ONLY legal multi-child layout (props only) ------ */
function Row({ gap = 0, align = "stretch", justify = "flex-start", wrap = false, children, style }) {
  return <div style={{ display: "flex", flexDirection: "row", gap, alignItems: align,
    justifyContent: justify, flexWrap: wrap ? "wrap" : "nowrap", ...style }}>{children}</div>;
}
function Column({ gap = 0, align = "stretch", justify = "flex-start", children, style }) {
  return <div style={{ display: "flex", flexDirection: "column", gap, alignItems: align,
    justifyContent: justify, ...style }}>{children}</div>;
}

/* ---- Text — plain text with a semantic style enum (no raw CSS) ---------- */
function Text({ style: variant = "body", children }) {
  return <span className={"t-" + variant}>{children}</span>;
}

/* ---- Markdown — inline **bold** / *italic* / `code` only ---------------- */
function Markdown({ text = "", children }) {
  const src = text || (typeof children === "string" ? children : "");
  const html = src
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
    .replace(/\*([^*]+)\*/g, "<em>$1</em>");
  return <p className="prose" dangerouslySetInnerHTML={{ __html: html }} />;
}

/* ---- Button — single child + action; emphasis enum (V4) ----------------- */
function Button({ emphasis = "secondary", action, children, disabled }) {
  return (
    <button className={"btn btn-" + emphasis} onClick={action} disabled={disabled}>
      {children}
    </button>
  );
}

/* ---- Jarvis presence (renderer chrome, keyed off stream state) ---------- */
function Presence({ state = "idle", name = "Jarvis" }) {
  const label = { idle: name + " · ready", thinking: name + " is thinking…", forging: "Forging…" }[state];
  return (
    <div className={"presence " + state}>
      <span className="presence-dot" />
      <span className="presence-label">{label}</span>
    </div>
  );
}

/* ---- ProgressRing — value 0..1; tone neutral|success|agent (never decorative ember)
   scale is a SEMANTIC enum (sm|md|lg), not an agent-set pixel size (V10). ---- */
function ProgressRing({ value = 0, label, sub, tone = "neutral", scale = "lg" }) {
  const [v, setV] = useState(0);
  useEffect(() => { const t = setTimeout(() => setV(value), 40); return () => clearTimeout(t); }, [value]);
  const size = { sm: 56, md: 72, lg: 96 }[scale] || 96;
  const stroke = 8, r = (size - stroke) / 2 - 2, c = 2 * Math.PI * r;
  const toneColor = { neutral: "var(--ink-muted)", success: "var(--success)", agent: "var(--agent-hot)" }[tone];
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-label={label ? label + (sub ? " " + sub : "") : undefined}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--hairline)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={toneColor} strokeWidth={stroke}
        strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - v)}
        transform={`rotate(-90 ${size/2} ${size/2})`}
        style={{ transition: "stroke-dashoffset 800ms cubic-bezier(0.34,1.56,0.64,1)" }} />
      {label != null && <text x="50%" y="47%" textAnchor="middle" fontFamily="General Sans, sans-serif"
        fontWeight="600" fontSize={size * 0.26} fill="var(--ink)">{label}</text>}
      {sub && <text x="50%" y="64%" textAnchor="middle" fontFamily="Switzer, sans-serif"
        fontSize={size * 0.12} fill="var(--ink-subtle)">{sub}</text>}
    </svg>
  );
}

/* ---- SkillMeter — tone neutral|success only (V3); delta = proposed ext (V11) */
function SkillMeter({ skill, value = 0, delta, tone = "neutral" }) {
  const [v, setV] = useState(0);
  useEffect(() => { const t = setTimeout(() => setV(value), 60); return () => clearTimeout(t); }, [value]);
  const color = { neutral: "var(--ink-muted)", success: "var(--success)" }[tone] || "var(--ink-muted)";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <span className="metric-label">{skill}</span>
        {delta != null
          ? <span className="skill-delta" title="proposed catalog extension — see audit V11"><span aria-hidden="true">▲</span> +{delta}</span>
          : <span className="metric-label" style={{ color: "var(--ink-subtle)" }}>{Math.round(value * 100)}%</span>}
      </div>
      <div className="skill-track"><div className="skill-fill" style={{ width: (v * 100) + "%", background: color }} /></div>
    </div>
  );
}

/* ---- CoachNote — Jarvis's voice, in-surface ---------------------------- */
function CoachNote({ tone = "hint", children }) {
  const title = { hint: "Hint", nudge: "Nudge", praise: "Praise", warn: "Heads up" }[tone];
  return (
    <div className={"coachnote cn-" + tone} role="note">
      <span className="rail" aria-hidden="true" />
      <div>
        <div className="cn-title">{title}</div>
        <div className="cn-body">{children}</div>
      </div>
    </div>
  );
}

/* ---- Reveal — summary + single child + BOUND open (V7) ------------------
   `open` is the bound value; `onToggle` lets the learner's tap write the
   pointer locally and (optionally) round-trip so Jarvis can react. */
function Reveal({ summary, open = false, onToggle, children }) {
  return (
    <div className="reveal" data-open={open}>
      <button className="reveal-summary" aria-expanded={open} onClick={() => onToggle && onToggle(!open)}>
        <span>{summary}</span>
        <span className="reveal-chev" aria-hidden="true"><Icon name="chevron-right" size={18} /></span>
      </button>
      {open && <div className="reveal-body weld-in">{children}</div>}
    </div>
  );
}

/* ---- CodeBlock — copy = the registered copyToClipboard function --------- */
function CodeBlock({ language = "text", code, copyable = true }) {
  const [copied, setCopied] = useState(false);
  const copyToClipboard = () => {           /* registered fn — local, no round-trip */
    navigator.clipboard?.writeText(code);
    setCopied(true); setTimeout(() => setCopied(false), 1400);
  };
  return (
    <div className="codeblock">
      <div className="cb-bar">
        <span className="cb-lang">{language}</span>
        {copyable && <button className="cb-copy" onClick={copyToClipboard}>
          <Icon name={copied ? "check" : "copy"} size={13} />{copied ? "copied" : "copy"}
        </button>}
      </div>
      <pre className="cb-code">{code}</pre>
    </div>
  );
}

Object.assign(window, { Icon, Row, Column, Text, Markdown, Button, Presence, ProgressRing, SkillMeter, CoachNote, Reveal, CodeBlock });
