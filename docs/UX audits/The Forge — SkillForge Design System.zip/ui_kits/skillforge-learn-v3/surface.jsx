/* surface.jsx — composite A2UI components + the surface shell (REVISED / v2).
   Conformance fixes vs v1:
   · QuizCard no longer grades locally — it fires answerSelected; correct/wrong arrives
     as bound `state`; non-color check/x icons added (V1 + a11y)
   · SkillMap receives TOPOLOGY only (id/label/mastery/state + edges); the renderer
     computes the constellation layout — no agent-sent x/y (V6)
   · PromptDiff "Forge" fires regeneratePrompt (round-trip); additions get a non-color
     marker; highlightDiff only paints the supplied segments (V8 + a11y)
   Depends on primitives.jsx. Exports to window. */
const { useState: useS2, useEffect: useE2, useMemo: useM2 } = React;

/* ---- Surface block: applies the Weld entrance (renderer-owned, keyed off state) */
function Block({ weld = true, flush = false, children }) {
  const [welding, setWelding] = useS2(weld);
  useE2(() => { if (!weld) return; const t = setTimeout(() => setWelding(false), 90); return () => clearTimeout(t); }, []);
  return <div className={"block" + (flush ? " flush" : "") + (weld ? " weld" : "")}
    data-welding={welding ? "true" : "false"}>{children}</div>;
}

/* Re-weldable wrapper for content swapped in place (a single updateComponents id) */
function Weld({ children, hold = 90, className = "", style }) {
  const [welding, setWelding] = useS2(true);
  useE2(() => { const t = setTimeout(() => setWelding(false), hold); return () => clearTimeout(t); }, []);
  return <div className={className} data-welding={welding ? "true" : "false"} style={style}>{children}</div>;
}

function Welded({ i = 0, children, tag = "div", style }) {
  const Tag = tag;
  return <Tag className="weld-in" style={{ ...style, transitionDelay: (i * 80) + "ms" }}>{children}</Tag>;
}

/* ---- ThinkingBlock: 1px agent sweep on the top hairline (NOT a skeleton) - v4 */
function ThinkingBlock() {
  return (
    <div className="thinking-block" role="status" aria-label="Jarvis is forging a surface">
      <span className="forming-label">Forging…</span>
    </div>
  );
}

/* ---- QuizCard — server-graded; `state` is bound, not computed here (V1) -
   props: prompt, choices, state {choiceKey: "correct"|"wrong"}, onAnswer(choice) */
function QuizCard({ prompt, choices, state, onAnswer }) {
  const [selected, setSelected] = useS2(null);
  const graded = state && Object.keys(state).length > 0;
  const locked = selected != null || graded;
  const pick = (k) => {
    if (locked) return;
    setSelected(k);                 /* local UI only — no grading */
    onAnswer && onAnswer(k);        /* fires the answerSelected event */
  };
  const cls = (k) => {
    if (graded) {
      if (state[k] === "correct") return "choice correct";
      if (state[k] === "wrong")   return "choice wrong";
      return "choice dim";
    }
    return "choice" + (k === selected ? " selected" : "");
  };
  const mark = (k) => {
    if (!graded) return null;
    if (state[k] === "correct") return <Icon name="check" size={16} color="var(--success)" className="ch-mark" />;
    if (state[k] === "wrong")   return <Icon name="x" size={16} color="var(--danger)" className="ch-mark" />;
    return null;
  };
  return (
    <div className="choices">
      <p className="quiz-prompt weld-in">{prompt}</p>
      {choices.map((c, i) => (
        <button key={c.key} className={cls(c.key) + " weld-in"} disabled={locked}
          style={{ transitionDelay: (i * 70 + 80) + "ms" }} onClick={() => pick(c.key)}>
          <span className="key">{c.key.toUpperCase()}</span>
          <span className="choice-label">{c.label}</span>
          {mark(c.key)}
        </button>
      ))}
    </div>
  );
}

/* ---- Step / Stepper ---------------------------------------------------- */
function Stepper({ steps, current = 0 }) {
  return (
    <div className="stepper">
      {steps.map((s, i) => {
        const st = i < current ? "done" : i === current ? "active" : "pending";
        const last = i === steps.length - 1;
        return (
          <div key={i} className={"step " + st}>
            <div className="step-rail">
              <div className="step-dot">
                {st === "done" && <Icon name="check" size={13} color="var(--ember-ink)" />}
                {st === "active" && <span className="core" />}
              </div>
              {!last && <div className="step-line" />}
            </div>
            <div style={{ flex: 1 }}>
              <div className="step-title">{s.title}</div>
              {st === "active" && s.body && <div className="step-body weld-in">{s.body}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/* ---- PromptDiff — Forge round-trips (V8); additions carry a non-color cue */
function PromptDiff({ before, afterSegments, verdict, value, onChange, onForge }) {
  return (
    <div>
      <div className="diff">
        <div className="diff-col diff-before">
          <div className="diff-head">Your prompt</div>
          <div className="diff-text">{before}</div>
        </div>
        <div className="diff-col diff-after">
          <div className="diff-head">Forged</div>
          <div className="diff-text">
            {afterSegments.map((seg, i) =>
              seg.t === "add" ? <span key={i} className="add"><span className="diff-mark" aria-hidden="true">+</span>{seg.v}</span>
              : seg.t === "del" ? <span key={i} className="del">{seg.v}</span>
              : <span key={i}>{seg.v}</span>)}
          </div>
        </div>
      </div>
      {verdict && <div className="verdict"><Icon name="sparkles" size={16} color="var(--ink-subtle)" /><span>{verdict}</span></div>}
      <textarea className="diff-edit" value={value} onChange={e => onChange && onChange(e.target.value)}
        spellCheck={false} aria-label="Edit your prompt" />
      <div className="btn-row" style={{ marginTop: 12 }}>
        <Button emphasis="primary" action={onForge}>
          <Row gap={8} align="center"><Icon name="flame" size={16} /><Text>Forge</Text></Row>
        </Button>
        <span className="metric-label" style={{ color: "var(--ink-subtle)" }}>Forge asks Jarvis to re-run the diff</span>
      </div>
    </div>
  );
}

/* ---- SkillMap — TOPOLOGY in, renderer computes layout (V6) --------------
   nodes: [{ id, label, mastery, state? }]   edges: [[idA, idB], ...]
   The agent never sends coordinates; we lay out a simple deterministic
   constellation here (renderer-owned). Mastery → node radius (non-color cue). */
function SkillMap({ nodes, edges, onNode }) {
  const W = 760, H = 340;
  const pos = useM2(() => {
    /* deterministic radial layout: index 0 at centre-left, others on a soft spiral */
    const cx = W * 0.32, cy = H * 0.52;
    const m = {};
    nodes.forEach((n, i) => {
      if (i === 0) { m[n.id] = { x: cx, y: cy }; return; }
      const ang = (i * 2.39996);                 /* golden-angle spread */
      const rad = 70 + i * 30;
      m[n.id] = { x: cx + Math.cos(ang) * rad * 1.35, y: cy + Math.sin(ang) * rad * 0.72 };
    });
    /* clamp into the frame */
    Object.values(m).forEach(p => {
      p.x = Math.max(60, Math.min(W - 60, p.x));
      p.y = Math.max(50, Math.min(H - 50, p.y));
    });
    return m;
  }, [nodes]);

  return (
    <svg className="skillmap" viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-label="Your skill map">
      {edges.map((e, i) => {
        const a = pos[e[0]], b = pos[e[1]];
        const na = nodes.find(n => n.id === e[0]), nb = nodes.find(n => n.id === e[1]);
        if (!a || !b) return null;
        const ready = (na && na.state === "ready") || (nb && nb.state === "ready");
        return <line key={i} className={"smap-edge" + (ready ? " ready" : "")}
          x1={a.x} y1={a.y} x2={b.x} y2={b.y} />;
      })}
      {nodes.map((n) => {
        const p = pos[n.id];
        const radius = 14 + n.mastery * 22;
        const fill = n.mastery > 0.66 ? "var(--success)" : "var(--ink-muted)";
        return (
          <g key={n.id} className={"smap-node" + (n.state === "ready" ? " ready" : "")} onClick={() => onNode && onNode(n)} tabIndex={0}>
            <circle className="fill" cx={p.x} cy={p.y} r={radius} fill={fill}
              fillOpacity={0.2} stroke={fill} strokeWidth={1.5} />
            <circle cx={p.x} cy={p.y} r={4} fill={fill} />
            <text x={p.x} y={p.y + radius + 16}>{n.label}</text>
          </g>
        );
      })}
    </svg>
  );
}

Object.assign(window, { Block, Weld, Welded, ThinkingBlock, QuizCard, Stepper, PromptDiff, SkillMap });
